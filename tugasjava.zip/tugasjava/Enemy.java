import greenfoot.*;  

/**
 * Write a description of class Enemy here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Enemy extends Actor
{
    public void act() 
    {
        // Add your action code here.
    }    
    public void moveEnemy()
    {
        
        setLocation(getX(),getY()+3);
    }
    public void removeEnemy()
    {
     
    }
}
