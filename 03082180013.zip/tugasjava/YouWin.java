import greenfoot.*;  

/**
 * Write a description of class YouWin here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class YouWin extends Actor
{
    public void act() 
    {
        // Add your action code here.
    }    
}
