import greenfoot.*; 
/**
 * Write a description of class Counter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Counter extends Actor
{
    int score = 0;
    public Counter()
    {
     setImage(new GreenfootImage("Score: "+ score,40,Color.RED, Color.BLACK) );   
    }
    public void act() 
    {
        setImage(new GreenfootImage("Score: "+ score, 40,Color.GREEN, Color.BLACK) );
        YouWin();
    }    
    public void addScore()
    {
     score++;   
    }
    public void YouWin()
    {
     if(score ==60)
     {
     getWorld().addObject(new YouWin(), 300,300);
     Greenfoot.stop();
        }
    }
}
