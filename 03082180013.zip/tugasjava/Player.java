import greenfoot.*; 
/**
 * Write a description of class Player here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Player extends Actor
{
    boolean shoot = true;
    public Player()
    {
      setRotation(270);   
    }
    public void act() 
    {
        moveAround();
        fireProjectile();
     }     
     
     public void moveAround()
     {
         if(Greenfoot.isKeyDown("right") )
         {
             setLocation(getX()+5,getY());
            }
            if(Greenfoot.isKeyDown("left"))
            {
             setLocation(getX()-5,getY());   
            }
      }
      public void fireProjectile()
      {
          if(Greenfoot.isKeyDown("space") && shoot == true)
          {
             getWorld().addObject(new Projectile(),getX(),getY() -30);
             shoot = false;
            }
            else if(!Greenfoot.isKeyDown("space") )
            {
                shoot = true;
            }
        }
}
