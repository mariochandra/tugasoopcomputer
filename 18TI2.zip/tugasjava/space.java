import greenfoot.*;  

/**
 * Write a description of class space here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class space extends World
{
    HealthBar healthbar = new HealthBar();
Counter counter = new Counter();
boolean bossLevel = false;
    
    public space()
    {    
        super(600, 600, 1); 
        prepare();
    }
    public Counter getCounter()
    {
        return counter;
    }
    public HealthBar getHealthBAr()
    {
     return healthbar;   
    }
    public void act()
    {
          addEnemy1();
          addEnemy2();
          
    }
   

   public void addEnemy1()
 {
     if(Greenfoot.getRandomNumber(120)<1)
   {
    addObject(new Enemy1(), Greenfoot.getRandomNumber(600),0);
 }
}
public void addEnemy2()
{
    if(Greenfoot.getRandomNumber(200)<1)
    {
        addObject(new Enemy2(), Greenfoot.getRandomNumber(600),0);
    }
}
    
    private void prepare()
    {
        addObject(counter,100,50);
        addObject(healthbar,250,50);
        Player player = new Player();
        addObject(player,333,368);
        player.setLocation(333,368);
        player.setLocation(254,460);
    }
}
